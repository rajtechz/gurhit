import Screen from "./Screen"
import "../src/assets/custom.css"
import { useState } from "react"

function App() {
  const [showID, setShowID] = useState(0);
  const [showData, setShowData] = useState([]);
  return (
    <section className="main__wrapper">
      <Screen showID={showID} setShowID={setShowID} showData={showData} setShowData={setShowData} />
    </section>
  )
}

export default App
